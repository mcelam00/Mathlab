%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Script que va a pedir por pantalla varios datos referente a part�culas
% que se van a plotear y calcular su centro de masas
% NO MODIFICAR EL NOMBRE DE LAS VARIABLES QUE SE INCUYEN
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Se pide por pantalla el n�mero de particulas que se va introducir.
...
    
% Se inicializa la matriz que va a almacenar las coordenadas y la masa de
% cada una de las part�culas
particulas = ...

% Se van pidiendo por pantalla los datos de todas las particulas
for ...
    ...
end

% Se iniciliza la variable donde se va a almacenar el centro de masas
centroDeMasas = ...
    
% Se calcula el centro de masas
...
    
% Inicializamos la figura en la que se van a plotear los datos
...
    
% Se plotea cada una de las part�culas a�adiendo el n�mero de la particula
% con una etiqueta en la que se inidica el valor de la masa.
for ...
    ...
end

% Se a�ade el centro de masas teniendo en cuenta que hay que cambiar la
% forma del punto para que destaque
...