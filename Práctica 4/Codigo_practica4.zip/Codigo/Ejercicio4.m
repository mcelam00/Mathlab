%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Crear un script que permita importar los datos del fichero 'Maqueta.csv'
% para ello utilizar el c�digo de script que genera la herramienta import
% data.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Insertar aqu� el c�digo que genera la herramienta de import data
...
    

% El resultado que devuelve el c�digo de importdata convertirlo a una
% matriz y almacenarlo en la variable maqueta.
Maqueta = ...