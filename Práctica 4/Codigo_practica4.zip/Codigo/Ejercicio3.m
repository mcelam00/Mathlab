%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Creaci�n de una script va a almacenar los datos de una matriz en dos
% ficheros de texto diferentes.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Creaci�n de la matriz
matriz = magic(6);

% Creaci�n del fichero de texto 'matriz.txt' que tiene que estar separado
% por tabuladores. Utilizar funciones de fopen y fprintf
...
    

% Creaci�n del fichero de texto 'matriz.csv' que tiene que ser un fichero
% csv delimitado por ';'
...