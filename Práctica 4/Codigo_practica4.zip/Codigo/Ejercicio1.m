%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Crear en una figura tres gr�ficas en las que se representen las
% relaciones trigonom�tricas del �ngulo alpha y alpha +pi/4. Una gr�fica
% ser� cont�nua en color rojo y la otra discontinua en color negro.
% Etiquetar cada una de ellas convenientemente
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Definimos la variable �ngulo que va a ser el eje de las x
alpha=0:pi/8:6*pi;

% Inicializamos la figura
...
    
% Ploteamos la primera gr�fica cos(alpha) & cos(alpha + pi/4)
% Ponemos t�tulo y leyenda
...
    
% Ploteamos la segunda gr�fica sin(alpha) & sin(alpha + pi/4)
% Ponemos t�tulo y leyenda
...
    
% Ploteamos la tercera gr�fica tan(alpha) & tan(alpha + pi/4)
% Ponemos t�tulo y leyenda y hay que limitar el eje y para que est� entre
% los valores -10 y 10
...