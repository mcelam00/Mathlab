function indices_folds = crear_k_fold(Y, k)
% Esta funci�n crea un vector (matriz fila) con tantos elementos como
% patrones que contiene el �ndice del fold en el que estar� el correspondiente
% patr�n. Esta asignaci�n se realiza aleatoriamente.
% Es decir, en la posici�n i-�sima del vector indices_folds estar� el n�mero 
% de fold (ENTRE 1 Y K) en el que estar� el patr�n i-�simo. LA FUNCI�N EST�
% DISE�ADA PARA PROBLEMAS DE DOS CLASES.
%
% INPUT
%   - Y: Vector que indica las clases de los patrones.
%   - k: N�mero de folds que hay que generar.
%
% OUTPUT
%   indices_folds: vector (matriz fila) con la misma longitud que Y. 
%   Contiene el �ndice del fold en el que estar� el correspondiente patr�n.
%   Es decir, en la posici�n i-�sima del vector de salida estar� el n�mero 
%   de fold en el que estar� el patr�n i-�simo.
%

	
end


