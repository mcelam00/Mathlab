
tic
%% Lectura del fichero
% Se solicita un fichero al usuario mediante la siguiente instrucci�n
[nombre_fichero,path_fichero] = uigetfile('*.txt','Selecciona fichero de datos crudos');
% Importamos los datos
nombreFichero_completo = fullfile(path_fichero,nombre_fichero);
datos_leidos = ...

% Tratamos las fechas para unir las dos columnas
fechaHora_cell_2Cols = datos_leidos.textdata(2:end,1:2);
fechaHora_str = strcat(fechaHora_cell_2Cols(:,1), {' '}, fechaHora_cell_2Cols(:,2));
fechaHoraNum = datenum(datetime(fechaHora_str));
    
% Construimos la matriz de datos
datos = ...

% Sacamos los nombres de las variables
variables = datos_leidos.textdata(1,1:end-3);    



%% Procesado de los datos

% Se buscan los huecos en la matriz y se rellenan con NaN. A continuaci�n, se buscan los elementos NaN
% y se rellenan con el valor de la fila anterior.
...

% Ploteo de la potencia activa
figure(1)
plot(...
title(...
ylabel('Potencia (kW)')
datetick('x', 'yyyy')
xlabel('Fecha')

% Calculo del cosphi
...
    
% Se a�aden a la gr�fica cruces rojas en los puntos en los que el
% cosphi es menor de 0.8. Para ello, se crea un vector auxiliar llamado 
% cosphi08, en el que se pone el valor NaN en las posiciones donde
% cosphi>=0.8
hold on
cosphi08 = ...
cosphi08(...)=NaN;
plot(...)

% Ploteo del histograma
figure(2)
...
title('Histograma de tensiones')
xlabel('Tension (V)')
ylabel('Numero de muestras')
    
% Maximo valor de potencia
[Potmax, Fecha] = ...
fprintf('El valor maximo de potencia es %0.2f para el dia %s \n', ...)

%% Reformatear la matriz para que en vez de datos por minutos que sean horarios
fechaHoraVec = datevec(datos(:,1));

[C, ia, ic] = unique(fechaHoraVec(:,1:4),'rows'); 
datos60 = zeros(max(ic),5);

% Mediante un bucle calculamos la media horaria para cada variable y lo
% guardamos en la matriz que hemos inicializado.
for ...
    indicesHora = find(ic==i);
    datos60(i,1) = datenum([fechaHoraVec(indicesHora(1),1:end-2) 0 0]);
    Temp = ...
    Temp = mean(Temp, 1, 'omitnan');
    ...
end

% Ploteo de la nueva Potencia horaria
figure (3)
plot(...)
title(...)
ylabel('Potencia (kW)')
datetick('x', 'yyyy')
xlabel('Fecha')

%% Importe de factura
% Tabla de precios por a�os: 
%   columna 1: precio por kWh durante los a�os y horas indicados en gui�n
%   columna 2: Precio total en cada a�o, mes y d�a dependiendo de la hora
%   (es decir, los precios por kWh por la potencia activa del mes, hora y
%   d�a correspondiente)
Precio = zeros(...);
Fechas = datevec(...);
Precio(...) = 0.15;
Precio(...) = 0.10;
Precio(...) = 0.09;
Precio(...) = 0.12;
Precio(...) = 0.17;

% Aplicamos el precio a los valores de potencia para obtener el importe

Precios_mes = zeros(...); % Matriz vacia donde almacenar los valores de importe por mes
Precio(:,2)=Precio(:,1).*...; %Sacamos los importes horarios
Precio(isnan(Precio)) = 0; % Si no hay valor guardamos un cero

% Calculamos el importe por meses 
for i=unique(Fechas(:,1))'
    for j=unique(Fechas(:,2))'
        Precios_mes(j, i-2006) = ...;
    end
end

% Ploteamos los datos
figure(5)
bar(...);
title('Facturas')
ylabel('Coste (�)')
xlabel('Fecha')
legend('2007','2008','2009','2010')

%% Guardado de la matriz
% Creamos un cell con los datos
Matriz = {};
Matriz(1,:)={'','2007','2008','2009','2010'};
Matriz = [Matriz; cellstr(datestr([ones(12,1)*2012 [1:12]' ones(12,1) ones(12,1) ones(12,1) ones(12,1)], 'mmm')), num2cell(Precios_mes)];

% Formateamos la matriz y escribimos el fichero.
fid = fopen('Facturas.txt', 'w+');
fprintf(fid, ...,  Matriz{1,:});
for i=2:length(Matriz)
    fprintf(fid, ...,  Matriz{i,:});
end
fclose(fid);
xlswrite('Prueba.xls', Matriz)

toc