% Incializacion del array
Criba =

% Hacer cero los elementos del array que no son primos
for ...